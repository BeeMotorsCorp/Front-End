// ==================== SISTEMA DE PERFIL GLOBAL ====================
// Versão 2.0 - Com suporte completo a CSS
// Adicione este script em TODAS as páginas: <script src="js/header-global.js"></script>
// E este CSS: <link rel="stylesheet" href="css/header-global.css">

class HeaderGlobal {
    constructor() {
        console.log('🚀 Inicializando HeaderGlobal...');
        this.verificarLogin();
        this.setupMenuDropdown();
        this.setupEventListeners();
    }

    verificarLogin() {
        const usuarioId = localStorage.getItem('usuario_id');
        const usuarioNome = localStorage.getItem('usuario_nome');
        
        const btnLoginContainer = document.getElementById('btnLoginContainer');
        const userProfileContainer = document.getElementById('userProfileContainer');
        const userName = document.getElementById('userName');
        
        if (usuarioId && usuarioNome) {
            // ✅ USUÁRIO LOGADO
            console.log('✅ Usuário logado:', usuarioNome);
            
            if (btnLoginContainer) {
                btnLoginContainer.style.display = 'none';
            }
            
            if (userProfileContainer) {
                userProfileContainer.style.display = 'flex';
                if (userName) {
                    userName.textContent = usuarioNome;
                }
            }
            
        } else {
            // ❌ USUÁRIO NÃO LOGADO
            console.log('❌ Usuário não logado');
            
            if (btnLoginContainer) {
                btnLoginContainer.style.display = 'flex';
            }
            
            if (userProfileContainer) {
                userProfileContainer.style.display = 'none';
            }
        }
    }

    setupMenuDropdown() {
        const userProfileBtn = document.getElementById('userProfileBtn');
        const userMenuDropdown = document.getElementById('userMenuDropdown');
        const menuLogout = document.getElementById('menuLogout');
        
        if (!userProfileBtn || !userMenuDropdown) {
            console.warn('⚠️ Elementos do menu dropdown não encontrados');
            return;
        }

        // ==================== TOGGLE DROPDOWN ====================
        userProfileBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            userMenuDropdown.classList.toggle('show');
            console.log('📱 Dropdown toggled:', userMenuDropdown.classList.contains('show'));
        });

        // ==================== NAVEGAÇÃO DO MENU ====================
        const menuPerfil = document.getElementById('menuPerfil');
        const menuMinhasCompras = document.getElementById('menuMinhasCompras');
        const menuConfiguracoes = document.getElementById('menuConfiguracoes');
        
        if (menuPerfil) {
            menuPerfil.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('📍 Navegando para: usuario.html');
                window.location.href = 'usuario.html';
            });
        }
        
        if (menuMinhasCompras) {
            menuMinhasCompras.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('📍 Navegando para: usuario.html#compras');
                window.location.href = 'usuario.html#compras';
            });
        }
        
        if (menuConfiguracoes) {
            menuConfiguracoes.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('📍 Navegando para: usuario.html#documentos');
                window.location.href = 'usuario.html#documentos';
            });
        }
        
        // ==================== LOGOUT ====================
        if (menuLogout) {
            menuLogout.addEventListener('click', (e) => {
                e.preventDefault();
                this.fazerLogout();
            });
        }

        // ==================== FECHAR AO CLICAR FORA ====================
        document.addEventListener('click', (e) => {
            if (!userProfileBtn.contains(e.target) && !userMenuDropdown.contains(e.target)) {
                userMenuDropdown.classList.remove('show');
            }
        });

        // ==================== FECHAR AO CLICAR EM ITEM ====================
        document.querySelectorAll('.user-menu-item').forEach(item => {
            item.addEventListener('click', () => {
                // Fechar dropdown após clicar
                setTimeout(() => {
                    userMenuDropdown.classList.remove('show');
                }, 100);
            });
        });
    }

    setupEventListeners() {
        // Sincronizar com outras abas
        window.addEventListener('storage', (e) => {
            if (e.key === 'usuario_id' || e.key === 'usuario_nome') {
                console.log('🔄 Sincronizando com outra aba...');
                this.verificarLogin();
            }
        });

        // Tecla Escape para fechar menu
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const dropdown = document.getElementById('userMenuDropdown');
                if (dropdown) {
                    dropdown.classList.remove('show');
                }
            }
        });
    }

    fazerLogout() {
        if (!confirm('Tem certeza que deseja sair?')) {
            return;
        }

        console.log('🔓 Realizando logout...');
        
        // Limpar localStorage
        localStorage.removeItem('usuario_id');
        localStorage.removeItem('usuario_nome');
        localStorage.removeItem('usuario_email');
        
        console.log('✅ Dados de sessão removidos');
        
        // Aguardar e redirecionar
        setTimeout(() => {
            window.location.href = 'home.html';
        }, 300);
    
    }

    // ==================== MÉTODO ESTÁTICO PARA ATUALIZAR PERFIL ====================
    static atualizarPerfil(nome, email) {
        localStorage.setItem('usuario_nome', nome);
        if (email) {
            localStorage.setItem('usuario_email', email);
        }
        
        const userName = document.getElementById('userName');
        if (userName) {
            userName.textContent = nome;
        }
        
        console.log('✅ Perfil atualizado:', nome);
    }

    static fazerLogin(usuarioId, usuarioNome, usuarioEmail = null) {
        localStorage.setItem('usuario_id', usuarioId);
        localStorage.setItem('usuario_nome', usuarioNome);
        if (usuarioEmail) {
            localStorage.setItem('usuario_email', usuarioEmail);
        }
        
        console.log('✅ Login realizado:', usuarioNome);
        
        // Recarregar header
        const headerGlobal = new HeaderGlobal();
    }
}

// ==================== INICIALIZAÇÃO ====================
document.addEventListener('DOMContentLoaded', () => {
    console.log('📄 DOM pronto - Inicializando HeaderGlobal');
    new HeaderGlobal();
});

// Fallback para se o script rodar após DOMContentLoaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new HeaderGlobal();
    });
} else {
    new HeaderGlobal();
}

console.log('✅ header-global.js carregado com sucesso!');