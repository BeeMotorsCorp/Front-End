<?php
// login.php
ob_start();

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    ob_end_clean();
    exit;
}

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

try {
    // Ler dados do POST
    $json = file_get_contents("php://input");
    
    if (empty($json)) {
        throw new Exception("Nenhum dado recebido");
    }
    
    $data = json_decode($json, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception("JSON inválido");
    }
    
    if (empty($data['email']) || empty($data['senha'])) {
        throw new Exception("Email e senha são obrigatórios");
    }
    
    $email = trim($data['email']);
    $senha = $data['senha'];
    
    // Incluir conexão
    include "conexao.php";
    
    if (!isset($conn)) {
        throw new Exception("Erro ao conectar com o banco");
    }
    
    if ($conn->connect_error) {
        throw new Exception("Erro de conexão: " . $conn->connect_error);
    }
    
    // Buscar usuário por email
    $stmt = $conn->prepare(
        "SELECT id, nome, sobrenome, cpf, email, telefone, senha 
         FROM usuarios WHERE email = ?"
    );
    
    if (!$stmt) {
        throw new Exception("Erro prepare: " . $conn->error);
    }
    
    $stmt->bind_param("s", $email);
    
    if (!$stmt->execute()) {
        throw new Exception("Erro execute: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $stmt->close();
        throw new Exception("Email ou senha incorretos");
    }
    
    $usuario = $result->fetch_assoc();
    $stmt->close();
    
    // Verificar senha
    if (!password_verify($senha, $usuario['senha'])) {
        throw new Exception("Email ou senha incorretos");
    }
    
    $conn->close();
    
    ob_end_clean();
    http_response_code(200);
    
    // Retornar dados do usuário
    echo json_encode([
        "status" => "ok",
        "mensagem" => "Login realizado com sucesso!",
        "usuario_id" => $usuario['id'],
        "usuario_nome" => $usuario['nome'],
        "usuario_email" => $usuario['email'],
        "usuario" => [
            "id" => $usuario['id'],
            "nome" => $usuario['nome'],
            "sobrenome" => $usuario['sobrenome'],
            "email" => $usuario['email'],
            "telefone" => $usuario['telefone'],
            "cpf" => $usuario['cpf']
        ]
    ]);
    
} catch (Exception $e) {
    if (isset($conn)) {
        @$conn->close();
    }
    
    ob_end_clean();
    http_response_code(400);
    
    echo json_encode([
        "status" => "error",
        "mensagem" => $e->getMessage()
    ]);
}

exit;
?>