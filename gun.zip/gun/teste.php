<?php
echo "Apache funcionando!<br>";
echo "Document Root: " . $_SERVER['DOCUMENT_ROOT'];
?>